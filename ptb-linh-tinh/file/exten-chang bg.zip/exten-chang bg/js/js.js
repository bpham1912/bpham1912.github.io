//Input your js here
 document.body.style.backgroundColor = "red";